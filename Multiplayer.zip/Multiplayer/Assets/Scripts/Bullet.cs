﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
	// Decreases health upon collision with a bullet
	void OnCollisionEnter (Collision collision)
	{
		var hit = collision.gameObject;
		var health = hit.GetComponent<Health> ();
		if (health != null) 
		{
			health.TakeDamage (5);
			Debug.Log ("Ouch!");
		}

		// Destroys bullet upon collision
		Destroy (gameObject);
	}
}
