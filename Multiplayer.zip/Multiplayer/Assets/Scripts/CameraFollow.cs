﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{

	public Transform playerTransform;
	float xrot = 0f;
	float yrot = 0f;
	private float XSensitivity = 50.0f;
	private float YSensitivity = 3.0f;

	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (playerTransform != null) {
			transform.position = playerTransform.position + new Vector3 (0, 0.5f, 0.4f);
			xrot += XSensitivity * Time.deltaTime * Input.GetAxis ("Mouse X");
			yrot -= YSensitivity * Input.GetAxis ("Mouse Y");
			transform.eulerAngles = new Vector3 (yrot, xrot, 0.0f);
		}
	}

	public void setTarget (Transform target)
	{
		playerTransform = target;
	}
}