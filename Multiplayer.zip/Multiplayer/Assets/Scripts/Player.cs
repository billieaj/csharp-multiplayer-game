﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Player : NetworkBehaviour
{
	public GameObject bulletPrefab;
	public Transform bulletSpawn1;
	public Transform bulletSpawn2;

	// Makes the local player appear blue
	public override void OnStartLocalPlayer ()
	{
		GetComponent<Renderer> ().material.color = Color.blue;
		Camera.main.GetComponent<CameraFollow> ().setTarget (gameObject.transform);
		Cursor.visible = false;
		Cursor.lockState = CursorLockMode.Locked;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (!isLocalPlayer) {
			return;
		}

		var x = Input.GetAxis ("Mouse X") * Time.deltaTime * 50.0f;
		var z = Input.GetAxis ("Vertical") * Time.deltaTime * 3.0f;
		var s = Input.GetAxis ("Horizontal") * Time.deltaTime * 3.0f;

		transform.Rotate (0, x, 0);
		transform.Translate (s, 0, z);

		// Fires bullets when the space key is pressed
		if (Input.GetKeyDown (KeyCode.Space)) {
			CmdFire ();
		}
	}

	[Command]
	void CmdFire ()
	{
		// Creates the bullets
		var bullet1 = (GameObject)Instantiate (bulletPrefab, bulletSpawn1.position, bulletSpawn1.rotation);
		var bullet2 = (GameObject)Instantiate (bulletPrefab, bulletSpawn2.position, bulletSpawn2.rotation);

		// Add velocity to the bullets
		bullet1.GetComponent<Rigidbody> ().velocity = bullet1.transform.forward * 6;
		bullet2.GetComponent<Rigidbody> ().velocity = bullet2.transform.forward * 6;

		// Spawns bullets on all clients
		NetworkServer.Spawn (bullet1);
		NetworkServer.Spawn (bullet2);

		// Destroys bullets after 2 seconds
		Destroy (bullet1, 2.0f);
		Destroy (bullet2, 2.0f);
	}
}
