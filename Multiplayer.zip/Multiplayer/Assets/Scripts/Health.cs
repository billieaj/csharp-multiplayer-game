﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class Health : NetworkBehaviour
{

	public const int maxHealth = 100;

	public bool destroyOnDeath;

	[SyncVar (hook = "OnChangeHealth")]
	public int currentHealth = maxHealth;

	public RectTransform healthBar;

	private NetworkStartPosition[] spawnPoints;

	void Start ()
	{
		if (isLocalPlayer)
		{
			spawnPoints = FindObjectsOfType<NetworkStartPosition>();
		}
	}

	// The player takes damage (when hit)
	public void TakeDamage (int amount)
	{
		if (!isServer)
			return;

		currentHealth -= amount;

		// What happens when health reaches zero
		if (currentHealth <= 0) 
		{
			// Destroys gameObject if the destroyOnDeath option is selected
			if (destroyOnDeath) 
			{
				Destroy (gameObject);
			} 
			// If the destroyOnDeath option is not selected, the health resets and the gameObject respawns
			else 
			{
				currentHealth = maxHealth;
				RpcRespawn ();
			}
		}
	}

	// Changes the size of the healthbar upon change to the health
	void OnChangeHealth (int health)
	{
		healthBar.sizeDelta = new Vector2 (health, healthBar.sizeDelta.y);
	}

	// Resets player position to zero
	[ClientRpc]
	void RpcRespawn ()
	{
		if (isLocalPlayer) 
		{
			Vector3 spawnPoint = Vector3.zero;

			if (spawnPoints != null && spawnPoints.Length > 0)
			{
				spawnPoint = spawnPoints[Random.Range(0, spawnPoints.Length)].transform.position;
			}

			transform.position = spawnPoint;
		}
	}
}
